
import  {signup_user} from "./main.js"

signupbtn.addEventListener('click',signup_user);

